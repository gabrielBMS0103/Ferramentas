const { ensureSchema, getPool } = require("./_db");

module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    res.status(405).json({ error: "Metodo nao permitido" });
    return;
  }

  try {
    await ensureSchema();
    const pool = getPool();

    const inspections = await pool.query(
      `SELECT id, date::text AS date, inspector, cpq, box
       FROM inspections
       ORDER BY date ASC, created_at ASC`
    );

    if (inspections.rowCount === 0) {
      res.status(200).json([]);
      return;
    }

    const ids = inspections.rows.map((r) => r.id);
    const items = await pool.query(
      `SELECT inspection_id, tool_id, name, qty, found, condition, discrepancy, notes, asset, sn
       FROM inspection_items
       WHERE inspection_id = ANY($1::text[])
       ORDER BY inspection_id, tool_id`,
      [ids]
    );

    const grouped = new Map();
    for (const row of inspections.rows) {
      grouped.set(row.id, {
        id: row.id,
        date: row.date,
        inspector: row.inspector,
        cpq: row.cpq,
        box: row.box,
        items: []
      });
    }
    for (const item of items.rows) {
      const rec = grouped.get(item.inspection_id);
      if (!rec) {
        continue;
      }
      rec.items.push({
        id: item.tool_id,
        name: item.name,
        qty: item.qty,
        found: item.found,
        condition: item.condition,
        discrepancy: item.discrepancy,
        notes: item.notes,
        asset: item.asset,
        sn: item.sn
      });
    }

    res.status(200).json(inspections.rows.map((r) => grouped.get(r.id)));
  } catch (error) {
    res.status(500).json({ error: `Falha ao carregar historico: ${error.message}` });
  }
};
