const { ensureSchema, getPool } = require("./_db");
const { validateRecord } = require("./_validation");

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    res.status(405).json({ error: "Metodo nao permitido" });
    return;
  }

  try {
    await ensureSchema();
    const record = validateRecord(req.body);
    const pool = getPool();
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(
        `INSERT INTO inspections
         (id, date, inspector, cpq, box, items_count, issues, result, next_date)
         VALUES ($1, $2::date, $3, $4, $5, $6, $7, $8, $9::date)`,
        [
          record.id,
          record.date,
          record.inspector,
          record.cpq,
          record.box,
          record.itemsCount,
          record.issues,
          record.result,
          record.nextDate
        ]
      );

      for (const item of record.items) {
        await client.query(
          `INSERT INTO inspection_items
           (inspection_id, tool_id, name, qty, found, condition, discrepancy, notes, asset, sn)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
          [
            record.id,
            item.toolId,
            item.name,
            item.qty,
            item.found,
            item.condition,
            item.discrepancy,
            item.notes,
            item.asset,
            item.sn
          ]
        );
      }

      await client.query("COMMIT");
      res.status(200).json({ ok: true, issues: record.issues });
    } catch (error) {
      await client.query("ROLLBACK");
      if (error.code === "23505") {
        res.status(409).json({ error: "Vistoria ja registrada" });
      } else {
        throw error;
      }
    } finally {
      client.release();
    }
  } catch (error) {
    if (/invalido|invalida|incompleto|inconsistentes/i.test(error.message)) {
      res.status(400).json({ error: error.message });
      return;
    }
    res.status(500).json({ error: `Nao foi possivel salvar: ${error.message}` });
  }
};
