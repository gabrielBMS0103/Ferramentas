const { Pool } = require("pg");

let pool;
let schemaReady = false;

function getPool() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL nao configurada.");
  }
  if (!pool) {
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: false }
    });
  }
  return pool;
}

async function ensureSchema() {
  if (schemaReady) {
    return;
  }
  const sql = `
    CREATE TABLE IF NOT EXISTS inspections (
      id TEXT PRIMARY KEY,
      date DATE NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT NOW(),
      inspector TEXT NOT NULL,
      cpq TEXT NOT NULL,
      box TEXT NOT NULL,
      items_count INTEGER NOT NULL,
      issues INTEGER NOT NULL,
      result TEXT NOT NULL,
      next_date DATE NOT NULL
    );

    CREATE TABLE IF NOT EXISTS inspection_items (
      inspection_id TEXT NOT NULL REFERENCES inspections(id) ON DELETE CASCADE,
      tool_id TEXT NOT NULL,
      name TEXT NOT NULL,
      qty INTEGER NOT NULL,
      found INTEGER NOT NULL,
      condition TEXT NOT NULL,
      discrepancy BOOLEAN NOT NULL,
      notes TEXT NOT NULL,
      asset TEXT NOT NULL,
      sn TEXT NOT NULL,
      PRIMARY KEY (inspection_id, tool_id)
    );
  `;
  const client = await getPool().connect();
  try {
    await client.query(sql);
    schemaReady = true;
  } finally {
    client.release();
  }
}

module.exports = {
  getPool,
  ensureSchema
};
