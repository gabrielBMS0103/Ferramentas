const ITEMS = require("./_inventory");

const VALID_CONDITIONS = new Set(["Boa", "Danificada", "Nao localizada", "Não localizada", "N/A"]);

function normalizeCondition(value) {
  if (value === "Não localizada") {
    return "Nao localizada";
  }
  return value;
}

function validateRecord(input) {
  if (!input || typeof input !== "object") {
    throw new Error("Registro invalido");
  }

  const { id, date, inspector, cpq, box, items } = input;

  if (typeof id !== "string" || !id.startsWith("VIS-") || id.length > 100) {
    throw new Error("ID invalido");
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || "")) {
    throw new Error("Data invalida");
  }
  const dt = new Date(`${date}T12:00:00Z`);
  if (Number.isNaN(dt.getTime())) {
    throw new Error("Data invalida");
  }
  if (typeof inspector !== "string" || !inspector.trim() || inspector.length > 100) {
    throw new Error("Responsavel invalido");
  }
  if (typeof cpq !== "string" || !cpq.trim() || cpq.length > 40) {
    throw new Error("CPQ invalido");
  }
  if (typeof box !== "string" || !box.trim() || box.length > 100) {
    throw new Error("Caixa invalida");
  }
  if (!Array.isArray(items) || items.length !== ITEMS.length) {
    throw new Error("Checklist incompleto");
  }

  const payloadIds = items.map((i) => i && i.id);
  const refIds = ITEMS.map((i) => i.id);
  if (JSON.stringify(payloadIds) !== JSON.stringify(refIds)) {
    throw new Error("Itens inconsistentes");
  }

  const normalizedItems = [];
  let issues = 0;
  for (let i = 0; i < items.length; i += 1) {
    const row = items[i];
    const ref = ITEMS[i];
    if (!Number.isInteger(row.found) || row.found < 0 || row.found > 9999) {
      throw new Error("Item invalido");
    }
    if (!VALID_CONDITIONS.has(row.condition)) {
      throw new Error("Item invalido");
    }
    const condition = normalizeCondition(row.condition);
    const notes = String(row.notes || "");
    if (notes.length > 500) {
      throw new Error("Item invalido");
    }

    const discrepancy = condition !== "N/A" && (row.found < ref.qty || condition !== "Boa");
    if (discrepancy) {
      issues += 1;
    }
    normalizedItems.push({
      toolId: ref.id,
      name: ref.name,
      qty: ref.qty,
      found: row.found,
      condition,
      discrepancy,
      notes,
      asset: String(ref.asset || ""),
      sn: String(ref.sn || "")
    });
  }

  const next = new Date(`${date}T12:00:00Z`);
  next.setUTCDate(next.getUTCDate() + 15);
  const nextDate = next.toISOString().slice(0, 10);

  return {
    id,
    date,
    inspector: inspector.trim(),
    cpq: cpq.trim(),
    box: box.trim(),
    itemsCount: normalizedItems.length,
    issues,
    result: issues ? "Com discrepancias" : "Conforme",
    nextDate,
    items: normalizedItems
  };
}

module.exports = {
  validateRecord
};
