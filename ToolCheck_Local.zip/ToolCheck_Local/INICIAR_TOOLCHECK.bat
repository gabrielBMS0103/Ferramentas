@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_EXE="
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYTHON_EXE=%LocalAppData%\Programs\Python\Python312\python.exe"
if not defined PYTHON_EXE if exist "%ProgramFiles%\Python312\python.exe" set "PYTHON_EXE=%ProgramFiles%\Python312\python.exe"
if not defined PYTHON_EXE for /f "delims=" %%P in ('where python 2^>nul') do (
  set "PYTHON_EXE=%%P"
  goto :python_found
)
:python_found
if not defined PYTHON_EXE (
  echo Python 3 nao encontrado.
  echo Instale em: https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

"%PYTHON_EXE%" servidor.py
pause
