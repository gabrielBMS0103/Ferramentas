from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import datetime, timedelta
import json
import sqlite3
import threading
import webbrowser
import socket

ROOT = Path(__file__).resolve().parent
DB = ROOT / "dados" / "toolcheck.db"
BOOK = ROOT / "dados" / "ToolCheck_CPQ11.xlsx"  # usado apenas para migracao inicial
LOCK = threading.Lock()


def _db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def _is_tool_id(v):
    return isinstance(v, str) and v.startswith("TOOL-")


def _read_history_from_excel():
    try:
        from openpyxl import load_workbook
    except Exception:
        return []

    if not BOOK.exists():
        return []

    wb = load_workbook(BOOK, read_only=True, data_only=True)
    try:
        ws = wb["Itens Conferidos"]
        grouped = {}
        for row in list(ws.values)[1:]:
            if not row or not row[0]:
                continue
            # formato antigo: id,data,responsavel,caixa,tool_id,...
            # formato novo:   id,data,responsavel,cpq,caixa,tool_id,...
            if len(row) >= 13 and _is_tool_id(row[4]):
                vid, date, person, box, tid, name, qty, found, condition, discrepancy, notes, asset, sn = row[:13]
                cpq = "CPQ11"
            elif len(row) >= 14 and _is_tool_id(row[5]):
                vid, date, person, cpq, box, tid, name, qty, found, condition, discrepancy, notes, asset, sn = row[:14]
            else:
                continue

            if vid not in grouped:
                grouped[vid] = {
                    "id": vid,
                    "date": str(date)[:10],
                    "inspector": person,
                    "cpq": cpq or "CPQ11",
                    "box": box or "CAB 5 BOX 2",
                    "items": [],
                }
            grouped[vid]["items"].append(
                {
                    "id": tid,
                    "name": name,
                    "qty": int(qty),
                    "found": int(found),
                    "condition": condition,
                    "discrepancy": discrepancy == "Sim",
                    "notes": notes or "",
                    "asset": asset or "",
                    "sn": sn or "",
                }
            )
        return list(grouped.values())
    finally:
        wb.close()


def _ensure_db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    con = _db()
    try:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS inspections (
                id TEXT PRIMARY KEY,
                date TEXT NOT NULL,
                created_at TEXT NOT NULL,
                inspector TEXT NOT NULL,
                cpq TEXT NOT NULL,
                box TEXT NOT NULL,
                items_count INTEGER NOT NULL,
                issues INTEGER NOT NULL,
                result TEXT NOT NULL,
                next_date TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS inspection_items (
                inspection_id TEXT NOT NULL,
                tool_id TEXT NOT NULL,
                name TEXT NOT NULL,
                qty INTEGER NOT NULL,
                found INTEGER NOT NULL,
                condition TEXT NOT NULL,
                discrepancy INTEGER NOT NULL,
                notes TEXT NOT NULL,
                asset TEXT NOT NULL,
                sn TEXT NOT NULL,
                PRIMARY KEY (inspection_id, tool_id),
                FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE
            );
            """
        )

        has_data = con.execute("SELECT 1 FROM inspections LIMIT 1").fetchone() is not None
        if not has_data:
            migrated = _read_history_from_excel()
            for record in migrated:
                issues = sum(1 for i in record["items"] if i["discrepancy"])
                dt = datetime.strptime(record["date"], "%Y-%m-%d")
                con.execute(
                    """
                    INSERT OR IGNORE INTO inspections
                    (id,date,created_at,inspector,cpq,box,items_count,issues,result,next_date)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                    """,
                    (
                        record["id"],
                        record["date"],
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        record["inspector"],
                        record.get("cpq") or "CPQ11",
                        record.get("box") or "CAB 5 BOX 2",
                        len(record["items"]),
                        issues,
                        "Com discrepâncias" if issues else "Conforme",
                        (dt + timedelta(days=15)).strftime("%Y-%m-%d"),
                    ),
                )
                con.executemany(
                    """
                    INSERT OR IGNORE INTO inspection_items
                    (inspection_id,tool_id,name,qty,found,condition,discrepancy,notes,asset,sn)
                    VALUES (?,?,?,?,?,?,?,?,?,?)
                    """,
                    [
                        (
                            record["id"],
                            item["id"],
                            item["name"],
                            item["qty"],
                            item["found"],
                            item["condition"],
                            1 if item["discrepancy"] else 0,
                            str(item.get("notes") or ""),
                            str(item.get("asset") or ""),
                            str(item.get("sn") or ""),
                        )
                        for item in record["items"]
                    ],
                )
        con.commit()
    finally:
        con.close()


def read_history():
    con = _db()
    try:
        inspections = con.execute(
            """
            SELECT id,date,inspector,cpq,box
            FROM inspections
            ORDER BY date ASC, created_at ASC
            """
        ).fetchall()
        history = []
        for r in inspections:
            items = con.execute(
                """
                SELECT tool_id,name,qty,found,condition,discrepancy,notes,asset,sn
                FROM inspection_items
                WHERE inspection_id = ?
                ORDER BY tool_id
                """,
                (r["id"],),
            ).fetchall()
            history.append(
                {
                    "id": r["id"],
                    "date": r["date"],
                    "inspector": r["inspector"],
                    "cpq": r["cpq"],
                    "box": r["box"],
                    "items": [
                        {
                            "id": i["tool_id"],
                            "name": i["name"],
                            "qty": i["qty"],
                            "found": i["found"],
                            "condition": i["condition"],
                            "discrepancy": bool(i["discrepancy"]),
                            "notes": i["notes"],
                            "asset": i["asset"],
                            "sn": i["sn"],
                        }
                        for i in items
                    ],
                }
            )
        return history
    finally:
        con.close()


def save_record(v):
    if not isinstance(v, dict):
        raise ValueError("Registro inválido")

    vid = v.get("id")
    date = v.get("date")
    person = v.get("inspector")
    cpq = v.get("cpq")
    box = v.get("box")
    items = v.get("items")

    if not isinstance(vid, str) or not vid.startswith("VIS-") or len(vid) > 100:
        raise ValueError("ID inválido")
    try:
        dt = datetime.strptime(date, "%Y-%m-%d")
    except (ValueError, TypeError):
        raise ValueError("Data inválida")
    if not isinstance(person, str) or not person.strip() or len(person) > 100:
        raise ValueError("Responsável inválido")
    if not isinstance(cpq, str) or not cpq.strip() or len(cpq) > 40:
        raise ValueError("CPQ inválido")
    if not isinstance(box, str) or not box.strip() or len(box) > 100:
        raise ValueError("Caixa inválida")
    if not isinstance(items, list) or len(items) != 23:
        raise ValueError("Checklist incompleto")

    from inventory import ITEMS

    if [i.get("id") for i in items] != [i["id"] for i in ITEMS]:
        raise ValueError("Itens inconsistentes")
    for i in items:
        if type(i.get("found")) is not int or not 0 <= i["found"] <= 9999:
            raise ValueError("Item inválido")
        if i.get("condition") not in ("Boa", "Danificada", "Não localizada", "N/A"):
            raise ValueError("Item inválido")
        if len(str(i.get("notes", ""))) > 500:
            raise ValueError("Item inválido")

    issues = 0
    item_rows = []
    for i, ref in zip(items, ITEMS):
        problem = i["condition"] != "N/A" and (i["found"] < ref["qty"] or i["condition"] != "Boa")
        if problem:
            issues += 1
        item_rows.append(
            (
                vid,
                ref["id"],
                ref["name"],
                ref["qty"],
                i["found"],
                i["condition"],
                1 if problem else 0,
                str(i.get("notes") or ""),
                str(ref.get("asset") or ""),
                str(ref.get("sn") or ""),
            )
        )

    with LOCK:
        con = _db()
        try:
            exists = con.execute("SELECT 1 FROM inspections WHERE id = ?", (vid,)).fetchone()
            if exists:
                raise ValueError("Vistoria já registrada")
            con.execute(
                """
                INSERT INTO inspections
                (id,date,created_at,inspector,cpq,box,items_count,issues,result,next_date)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    vid,
                    date,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    person.strip(),
                    cpq.strip(),
                    box.strip(),
                    len(items),
                    issues,
                    "Com discrepâncias" if issues else "Conforme",
                    (dt + timedelta(days=15)).strftime("%Y-%m-%d"),
                ),
            )
            con.executemany(
                """
                INSERT INTO inspection_items
                (inspection_id,tool_id,name,qty,found,condition,discrepancy,notes,asset,sn)
                VALUES (?,?,?,?,?,?,?,?,?,?)
                """,
                item_rows,
            )
            con.commit()
        finally:
            con.close()
    return {"ok": True, "issues": issues}


def _local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        try:
            return socket.gethostbyname(socket.gethostname())
        except Exception:
            return "127.0.0.1"


class Handler(BaseHTTPRequestHandler):
    def respond(self, code, data):
        b = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path == "/":
            b = (ROOT / "index.html").read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
        elif self.path == "/api/history":
            try:
                self.respond(200, read_history())
            except Exception as e:
                self.respond(500, {"error": str(e)})
        elif self.path == "/api/server-info":
            ip = _local_ip()
            self.respond(
                200,
                {
                    "localUrl": "http://127.0.0.1:8765/",
                    "networkUrl": f"http://{ip}:8765/",
                    "database": str(DB),
                },
            )
        else:
            self.send_error(404)

    def do_POST(self):
        if self.path != "/api/save":
            self.send_error(404)
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size <= 0 or size > 100000:
                self.respond(413, {"error": "Tamanho inválido"})
                return
            data = json.loads(self.rfile.read(size))
            self.respond(200, save_record(data))
        except ValueError as e:
            self.respond(400, {"error": str(e)})
        except Exception as e:
            self.respond(500, {"error": "Não foi possível salvar: " + str(e)})


if __name__ == "__main__":
    from inventory import ITEMS  # garante que o inventario esta disponivel

    _ensure_db()
    ip = _local_ip()
    server = ThreadingHTTPServer(("0.0.0.0", 8765), Handler)
    print("ToolCheck local:   http://127.0.0.1:8765/", flush=True)
    print(f"ToolCheck rede:    http://{ip}:8765/", flush=True)
    print(f"Banco de dados:    {DB}", flush=True)
    webbrowser.open("http://127.0.0.1:8765/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
